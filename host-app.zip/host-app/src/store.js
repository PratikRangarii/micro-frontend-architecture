import { create } from "zustand";  // ✅ Correct import

const useStore = create((set) => ({
  messages: [],
  emails: [],
  addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),
  addEmail: (email) => set((state) => ({ emails: [...state.emails, email] })),
}));

export default useStore;
