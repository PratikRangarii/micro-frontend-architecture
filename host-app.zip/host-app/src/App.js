import React, { Suspense } from "react";
import useStore from "./store"; // Import Zustand store

const ChatApp = React.lazy(() => import("chat/ChatComponent"));
const EmailApp = React.lazy(() => import("email/EmailComponent"));

function App() {
  const { messages, emails } = useStore(); // Access shared state

  return (
    <div>
      <h1>Host Application</h1>
      <h3>Shared Chat Messages:</h3>
      <ul>{messages.map((msg, index) => <li key={index}>{msg}</li>)}</ul>

      <h3>Shared Emails:</h3>
      <ul>{emails.map((email, index) => <li key={index}>{email}</li>)}</ul>

      <Suspense fallback={<div>Loading Chat...</div>}>
        <ChatApp />
      </Suspense>
      <Suspense fallback={<div>Loading Email...</div>}>
        <EmailApp />
      </Suspense>
    </div>
  );
}

export default App;
