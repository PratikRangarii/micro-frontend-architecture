import React, { useState } from "react";
import useStore from "host/store"; //  Correct import

const ChatComponent = () => {
  const [message, setMessage] = useState("");
  const messages = useStore((state) => state.messages); //  Use Zustand selector
  const addMessage = useStore((state) => state.addMessage);

  const sendMessage = () => {
    if (message) {
      addMessage(message); //  Ensure Zustand state updates
      setMessage("");
    }
  };

  return (
    <div style={{ border: "1px solid black", padding: "20px" }}>
      <h3>Chat Application</h3>
      <input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Type a message" />
      <button onClick={sendMessage}>Send</button>
      <ul>
        {messages.map((msg, index) => (
          <li key={index}>{msg}</li>
        ))}
      </ul>
    </div>
  );
};

export default ChatComponent;
