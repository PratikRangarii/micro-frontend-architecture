import React, { useState } from "react";
import useStore from "host/store"; // Import Zustand store from Host

const EmailComponent = () => {
  const [email, setEmail] = useState("");
  const emails = useStore((state) => state.emails); // Use Zustand selector
  const addEmail = useStore((state) => state.addEmail);

  const sendEmail = () => {
    if (email) {
      addEmail(email);
      setEmail("");
    }
  };

  return (
    <div style={{ border: "1px solid black", padding: "20px" }}>
      <h3>Email Application</h3>
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Type an email" />
      <button onClick={sendEmail}>Send</button>
      <ul>
        {emails.map((mail, index) => (
          <li key={index}>{mail}</li>
        ))}
      </ul>
    </div>
  );
};

export default EmailComponent;
